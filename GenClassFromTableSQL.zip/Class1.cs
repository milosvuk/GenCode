using System;
using System.Collections.Generic;

namespace WinTest
{
	public class Class1
	{
		public Class1()
		{
			
		}

		public Class1(string mkk,string ss)
		{
			mm =mkk;
			
		}

		private System.String mm;

		public System.String Mm
		{
			get
			{
			  return mm;
			}
			set
			{
			 mm = value;
			}
		}

	}
}
