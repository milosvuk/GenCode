using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
 
namespace ptl
{
public class clastest
 
public clastest()
{
 
}
}
}
